//
//  Constants.swift
//  Bounce
//
//  Created by Leon Böttger on 06.04.23.
//

import Foundation
import SwiftUI

/// Struct to store constant parameters
public struct Constants {
    
    /// corner radius for labels
    static let cornerRadius: CGFloat = 10
    
    /// height of buttons and labels
    static let labelHeight: CGFloat = 70
    
    /// max width of content
    static let maxWidth: CGFloat = 800
}
