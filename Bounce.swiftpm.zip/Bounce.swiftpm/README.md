# Bounce - WWDC23 Swift Student Challenge

## Summary

Bounce is an app targeted towards SwiftUI developers. The app presents, visualizes and explains SwiftUI animations, so developers can choose the perfect animation for their intended use.

## How to run

The app runs best with an 11 or 12.9-inch iPad Pro (real device or simulator) in portrait mode. However, any other device should work fine as well.
