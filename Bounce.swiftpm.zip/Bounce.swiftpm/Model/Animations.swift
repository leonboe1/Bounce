//
//  Animations.swift
//  Bounce
//
//  Created by Leon Böttger on 07.04.23.
//

import Foundation

/// Array storing all animation categories for presentation in the app
let animationCategories: [AnimationCategory] = [
    
    // linear
    AnimationCategory(animations:   [LinearAnimation()]),
    
    // ease animations
    AnimationCategory(animations: [EaseInOutAnimation(),
                                   EaseInAnimation(),
                                   EaseOutAnimation()]),
    
    // springs
    AnimationCategory(animations: [SpringAnimation(),
                                   InteractiveSpringAnimation(),
                                   InterpolatingSpringAnimation()])
]
