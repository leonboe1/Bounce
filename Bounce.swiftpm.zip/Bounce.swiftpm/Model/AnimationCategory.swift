//
//  AnimationCategory.swift
//  Bounce
//
//  Created by Leon Böttger on 10.04.23.
//

import SwiftUI

/// Model for storing data of a animation category
class AnimationCategory: Equatable, Identifiable, Hashable {
    
    /// Initializes an AnimationCategory with multiple animations
    init(animations: [AnimationWrapper]) {
        self.animations = animations
    }
    
    /// The stored animations
    var animations: [AnimationWrapper]
    
    /// For Identifiable
    var id = UUID()
    
    /// For Equatable
    static func == (lhs: AnimationCategory, rhs: AnimationCategory) -> Bool {
        lhs.id == rhs.id
    }
    
    /// For Hashable
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
}
