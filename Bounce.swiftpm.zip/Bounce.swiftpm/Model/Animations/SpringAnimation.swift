//
//  SpringAnimation.swift
//  Bounce
//
//  Created by Leon Böttger on 07.04.23.
//

import SwiftUI

/// Modelling the default Spring Animation
class SpringAnimation: AnimationWrapper {
    
    override init() {
        
        super.init()
        
        name = "Spring"
        
        codeFormat =
        """
static func spring(
    response: Double = 0.55,
    dampingFraction: Double = 0.825,
    blendDuration: Double = 0
) -> Animation
"""
        description = "A Spring animation often feels the most natural. It starts slowly, accelerates in the middle, moves to the desired point, and overshoots a bit. After that, the animation bounces back. The response parameter simulates the weight of an object. The smaller it is, the easier the object will move or stop moving. The damping fraction determines how long the spring animation can bounce. A higher value will stop the bouncing earlier. The blend duration parameter is only relevant if multiple animations are used on the same object."
        
        // Animation allows to modify response, damping and blendDuration -> need for spring configuration
        configuration = SpringConfiguration(response: 0.55, dampingFraction: 0.825, blendDuration: 0)
    }

    override func getAnimation() -> Animation {
        let config = configuration as! SpringConfiguration
        return Animation.spring(response: config.response, dampingFraction: config.dampingFraction, blendDuration: config.blendDuration)
    }
}
