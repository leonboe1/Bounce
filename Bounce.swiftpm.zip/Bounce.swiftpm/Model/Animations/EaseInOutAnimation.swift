//
//  EaseInOutAnimation.swift
//  Bounce
//
//  Created by Leon Böttger on 07.04.23.
//

import SwiftUI

/// Modelling the Ease In Out Animation
class EaseInOutAnimation: AnimationWrapper {
    
    override init() {
        
        super.init()
        
        name = "Ease In & Out"
        
        codeFormat = "static func easeInOut(duration: Double) -> Animation"
        
        description = "The Ease In & Out animation is the default animation. It starts slowly, accelerates in the middle of the animation and brakes again towards the end of the animation. The duration parameter of the Ease In & Out animation determines the length of the animation in seconds. Try to adjust it and start the animation with \"Animate!\"."
        
        // Animation only allows to modify its duration
        configuration = DurationConfiguration()
    }
    
    override func getAnimation() -> Animation {
        
        return Animation.easeInOut(duration: (configuration as! DurationConfiguration).duration)
    }
}
