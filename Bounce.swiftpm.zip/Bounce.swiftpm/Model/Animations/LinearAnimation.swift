//
//  LinearAnimation.swift
//  Bounce
//
//  Created by Leon Böttger on 07.04.23.
//

import SwiftUI

/// Modelling the Linear Animation
class LinearAnimation: AnimationWrapper {
        
    override init() {
        
        super.init()
        
        name = "Linear"
        
        codeFormat = "static func linear(duration: Double) -> Animation"
        
        description = "The Linear animation is probably the simplest animation. The animation has a constant speed, and therefore seems somewhat mechanical. The duration parameter of the linear animation determines the length of the animation in seconds. Try to adjust it and start the animation with \"Animate!\"."
        
        // Animation only allows to modify its duration
        configuration = DurationConfiguration()
    }
    
    override func getAnimation() -> Animation {
        
        return Animation.linear(duration: (configuration as! DurationConfiguration).duration)
    }
}
