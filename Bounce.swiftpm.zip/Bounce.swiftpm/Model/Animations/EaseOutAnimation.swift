//
//  EaseOutAnimation.swift
//  Bounce
//
//  Created by Leon Böttger on 07.04.23.
//

import SwiftUI

/// Modelling the Ease Out Animation
class EaseOutAnimation: AnimationWrapper {
    
    override init() {
        
        super.init()
        
        name = "Ease Out"
        
        codeFormat = "static func easeOut(duration: Double) -> Animation"
        
        description = "The Ease Out animation starts fast and abruptly, but smoothly fades out towards the end of the animation. The duration parameter of the Ease Out animation determines the length of the animation in seconds. Try to adjust it and start the animation with \"Animate!\"."
        
        // Animation only allows to modify its duration
        configuration = DurationConfiguration()
    }
    
    override func getAnimation() -> Animation {
        
        return Animation.easeOut(duration: (configuration as! DurationConfiguration).duration)
    }
}
