//
//  InterpolatingSpringAnimation.swift
//  Bounce
//
//  Created by Leon Böttger on 07.04.23.
//

import SwiftUI

/// Modelling the Interpolating Spring Animation
class InterpolatingSpringAnimation: AnimationWrapper {
    
    override init() {
        
        super.init()
        
        name = "Interpolating Spring"
        
        codeFormat =
        """
static func interpolatingSpring(
    mass: Double = 1.0,
    stiffness: Double,
    damping: Double,
    initialVelocity: Double = 0.0
) -> Animation
"""
        description = "The Interpolating Spring animation behaves similar to the regular Spring, but can be configured based on different parameters. The mass parameter simulates the weight of the animated object. The smaller it is, the easier the object will move or stop moving. The stiffness modifies the tensile strength. A higher value results in a bouncier animation. The damping determines how long the spring animation can bounce. A higher value will stop the bouncing earlier. The initial velocity defines the speed the object is moving at the beginning of the animation. By default, it is set to zero."
        
        // Animation allows to modify mass, stiffness, damping and initial velocity -> need for new interpolating spring configuration
        configuration = InterpolatingSpringConfiguration(mass: 1, stiffness: 80, damping: 8, initialVelocity: 0)
    }

    override func getAnimation() -> Animation {
        let config = configuration as! InterpolatingSpringConfiguration
        return Animation.interpolatingSpring(mass: config.mass, stiffness: config.stiffness, damping: config.damping, initialVelocity: config.initialVelocity)
    }
}
