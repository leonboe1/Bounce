//
//  EaseInAnimation.swift
//  Bounce
//
//  Created by Leon Böttger on 07.04.23.
//

import SwiftUI

/// Modelling the Ease In Animation
class EaseInAnimation: AnimationWrapper {
    
    override init() {
        
        super.init()
        
        name = "Ease In"
        
        codeFormat = "static func easeIn(duration: Double) -> Animation"
        
        description = "The Ease In animation starts slowly and speeds up towards the end of the animation. It does not slow down at the end of the animation, causing it to end abruptly. The duration parameter of the Ease In animation determines the length of the animation in seconds. Try to adjust it and start the animation with \"Animate!\"."
        
        // Animation only allows to modify its duration
        configuration = DurationConfiguration()
    }
    
    override func getAnimation() -> Animation {
        
        return Animation.easeIn(duration: (configuration as! DurationConfiguration).duration)
    }
}
