//
//  InteractiveSpringAnimation.swift
//  Bounce
//
//  Created by Leon Böttger on 07.04.23.
//

import SwiftUI

/// Modelling the Interactive Spring Animation
class InteractiveSpringAnimation: AnimationWrapper {
    
    override init() {
        
        super.init()
        
        name = "Interactive Spring"
        
        codeFormat =
        """
static func interactiveSpring(
    response: Double = 0.15,
    dampingFraction: Double = 0.86,
    blendDuration: Double = 0.25
) -> Animation
"""
        description = "The Interactive Spring animation behaves exactly like the normal Spring animation. The only difference is that the default values for the blend, damping and response parameters are set so the animation is faster."
        
        // Animation allows to modify response, damping and blendDuration -> need for spring configuration
        configuration = SpringConfiguration(response: 0.15, dampingFraction: 0.86, blendDuration: 0.25)
    }

    override func getAnimation() -> Animation {
        let config = configuration as! SpringConfiguration
        return Animation.spring(response: config.response, dampingFraction: config.dampingFraction, blendDuration: config.blendDuration)
    }
}
