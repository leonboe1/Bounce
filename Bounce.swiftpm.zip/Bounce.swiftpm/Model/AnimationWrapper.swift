//
//  AnimationWrapper.swift
//  Bounce
//
//  Created by Leon Böttger on 05.04.23.
//

import SwiftUI

/// Wrapper to model an animation with name, description, code and SwiftUI 'Animation' for demonstration
class AnimationWrapper: Equatable, Identifiable, Hashable {
    
    /// The name of the animation - for UI
    var name = "name"
    
    /// The code how to initialize the animation with Swift - for UI
    var codeFormat = "codeFormat"
    
    /// The description of the animation - for UI
    var description = "description"
    
    /// The configuration to store the parameters to change the animation's behavior (duration, speed, etc.)
    var configuration: AnimationConfiguration = DurationConfiguration()
    
    /// For Identifiable
    var id = UUID()
    
    /// Returns the animation considering the current configuration
    func getAnimation() -> Animation {
        return .default
    }
    
    /// For Equatable
    static func == (lhs: AnimationWrapper, rhs: AnimationWrapper) -> Bool {
        lhs.id == rhs.id
    }
    
    /// For Hashable
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
}
