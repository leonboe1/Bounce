import SwiftUI

@main
struct Bounce: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
