//
//  DurationConfiguration.swift
//  Bounce
//
//  Created by Leon Böttger on 07.04.23.
//

import SwiftUI

/// Stores configuration consisting of a duration parameter
class DurationConfiguration: AnimationConfiguration, ObservableObject {
    
    /// The duration
    @Published var duration: Double = 1
}
