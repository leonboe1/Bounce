//
//  InterpolatingSpringConfiguration.swift
//  Bounce
//
//  Created by Leon Böttger on 07.04.23.
//

import SwiftUI

/// Stores configuration consisting of a mass, stiffness, damping and initial velocity parameter
class InterpolatingSpringConfiguration: AnimationConfiguration, ObservableObject {
    
    /// The modeled mass parameter
    @Published var mass: Double
    
    /// The modeled stiffness parameter
    @Published var stiffness: Double
    
    /// The modeled damping parameter
    @Published var damping: Double
    
    /// The modeled parameter for the initial velocity
    @Published var initialVelocity: Double
    
    init(mass: Double, stiffness: Double, damping: Double, initialVelocity: Double) {
        self.mass = mass
        self.stiffness = stiffness
        self.damping = damping
        self.initialVelocity = initialVelocity
    }
}
