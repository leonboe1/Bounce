//
//  SpringConfiguration.swift
//  Bounce
//
//  Created by Leon Böttger on 07.04.23.
//

import SwiftUI

/// Stores configuration consisting of a response, damping and blend duration parameter
class SpringConfiguration: AnimationConfiguration, ObservableObject {
    
    /// The modeled response parameter
    @Published var response: Double
    
    /// The modeled damping fraction parameter
    @Published var dampingFraction: Double
    
    /// The modeled parameter of the blend duration 
    @Published var blendDuration: Double
    
    init(response: Double, dampingFraction: Double, blendDuration: Double) {
        self.response = response
        self.dampingFraction = dampingFraction
        self.blendDuration = blendDuration
    }
}

