//
//  AnimationConfiguration.swift
//  Bounce
//
//  Created by Leon Böttger on 07.04.23.
//

import SwiftUI

/// Protocol to implement by every specialized configuration
protocol AnimationConfiguration {
    
}
