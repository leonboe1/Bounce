//
//  BigButtonView.swift
//  Bounce
//
//  Created by Leon Böttger on 07.04.23.
//

import SwiftUI

struct BigButtonView<T1: View, T2: View>: View {
    @Environment(\.colorScheme) private var colorScheme
    @State private var blurOpacity: Double = 0
    let buttonHeight: CGFloat
    let mainView: T1
    let buttonView: T2
    
    var body: some View {
        
        ZStack {
            GeometryReader { geometry in
                
                ScrollView(showsIndicators: false) {
                 
                    mainView
 
                    .frame(minHeight: geometry.size.height - buttonHeight)
                    .padding(.bottom, buttonHeight)
                }
                .frame(maxWidth: .infinity)
            }
            
            
            VStack {
                
                Spacer()
                buttonView
                    .frame(maxWidth: .infinity)
                    .frame(height: buttonHeight)
                    .background(
                        Blur().brightness(getBrightness()).edgesIgnoringSafeArea(.all)
                    )
            }
            
            .ignoresSafeArea(.keyboard)

        }
        .modifier(CustomFormBackground())
    }
    
    /// Returns the value required to make Blur() the same color as the background
    func getBrightness() -> Double {
        return colorScheme == .light ? 0.04 : -0.065
        
    }
}

struct Blur: UIViewRepresentable {
    
    var style: UIBlurEffect.Style = .systemUltraThinMaterial
    
    func makeUIView(context: Context) -> UIVisualEffectView {
        return UIVisualEffectView(effect: UIBlurEffect(style: style))
    }
    
    func updateUIView(_ uiView: UIVisualEffectView, context: Context) {
        uiView.effect = UIBlurEffect(style: style)
    }
}
