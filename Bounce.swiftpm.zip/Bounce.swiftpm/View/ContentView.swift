import SwiftUI

struct ContentView: View {
    
    @State private var columnVisibility =
    NavigationSplitViewVisibility.doubleColumn
    
    var body: some View {
        
        if(isiPad()) {
            NavigationSplitView(columnVisibility: $columnVisibility) {
                MainView()
                
            } detail: {
                AnimationView(animation: animationCategories.first!.animations.first!)
            }
            .navigationSplitViewStyle(.balanced)
        }
        else {
            NavigationStack {
                MainView()
            }
        }
    }
}

struct MainView: View {
    
    var body: some View {
        
        ScrollView {
            VStack(spacing: 30) {
                
                Text("Want to learn about SwiftUI animations interactively? Click on a button below to learn more about an animation and to see it in action!")
                    .foregroundColor(.white)
                    .padding(.vertical)
                    .modifier(FieldModifier(color: .blue))
                
                VStack(spacing: 30) {
                    ForEach(animationCategories) { animationCategory in
                        VStack(spacing: 0) {
                            ForEach(animationCategory.animations) { animation in
                                
                                
                                NavigationLink {
                                    AnimationView(animation: animation)
                                        .id(animation.id)
                                } label: {
                                    AnimationOverviewView(animation: animation)
                                }
                                
                                if(animation != animationCategory.animations.last) {
                                    Divider()
                                }
                            }
                        } .modifier(CustomFormModifier())
                    }
                    
                }
            }
            .frame(maxWidth: Constants.maxWidth)
            .padding(.horizontal)
            .padding(.top)
        }
        .navigationBarTitle("Bounce")
        .modifier(CustomFormBackground())
    }
}

struct CustomFormBackground: ViewModifier {
    @Environment(\.colorScheme) var colorScheme
    func body(content: Content) -> some View {
        content
            .background(Color("FormBackground").ignoresSafeArea())
    }
}
