//
//  Button.swift
//  Bounce
//
//  Created by Leon Böttger on 07.04.23.
//

import SwiftUI

public struct LargeButton: View {
    
    public let imageName: String
    public let description: String
    public let action: () -> ()
    
    public init(imageName: String, description: String, action: @escaping () -> ()) {
        self.imageName = imageName
        self.description = description
        self.action = action
    }
    
    public var body: some View {
        Button(action: action) {
            HStack {
                Image(systemName: imageName)
                
                Text(description)
            }.frame(height: 15)
                .modifier(ButtonModifier())
        }
    }
}


public struct ButtonModifier: ViewModifier {
    
    public func body(content: Content) -> some View {
        content
            .foregroundColor(.white)
            .font(.headline)
            .padding()
            .frame(minWidth: 0, maxWidth: 300, alignment: .center)
            .background(Color.blue.cornerRadius(15))
    }
}
