//
//  Graph.swift
//  Bounce
//
//  Created by Leon Böttger on 06.04.23.
//

import SwiftUI

struct GraphView: View {
    
    @ObservedObject var graph: AnimationGraphDataModel
    
    let moveWidth: CGFloat
    
    var body: some View {
        ZStack {
            VStack {
                Graph(points: graph.points)
                    .stroke(Color.blue, lineWidth: 2)
                    .frame(height: 200)
                    .background(
                        
                        Rectangle()
                                
                        .stroke(Color.gray.opacity(0.5), style: .init(lineWidth: 1))
                        .padding(.top, -1)
                        .padding(.trailing, -1)
                        .clipped())
                
                Text("Time")
                    .opacity(0.5)
            }
            
            Text("Position")
                .rotationEffect(Angle(degrees: 90))
                .opacity(0.5)
                .offset(x: -moveWidth/2 - 25, y: -7)
        }
    }
}

struct GraphPoint: Equatable {
    let time: CGFloat
    let percentage: CGFloat
    let id = UUID()
}

struct Graph: Shape {
    
    var points: [GraphPoint]
    
    /// Calculates the line of the graph view
    func path(in rect: CGRect) -> Path {
        
        var path = Path()
        
        if let first = points.first, let last = points.last {
            
            let startTime = first.time
            let time = last.time - first.time
            
            var percentageDisplayed: CGFloat = 1
            
            let max = points.max { a, b in
                a.percentage < b.percentage
            }?.percentage ?? 1
            
            let min = points.min { a, b in
                a.percentage < b.percentage
            }?.percentage ?? 0
            
            var yoffset: CGFloat = 0
            
            // If there is an under/overflow (spring animation), account for that
            if(max > 1) {
                percentageDisplayed = max
            }
            if(min < 0) {
                percentageDisplayed -= (min)
                yoffset = min
            }
            
            for point in points {
                
                let x = rect.minX + ((point.time - startTime) / time) * rect.width
                
                let y = rect.maxY - CGFloat((point.percentage - yoffset)/percentageDisplayed) * rect.height
                
                if(point != points.first) {
                    // add line from previous point
                    path.addLine(to: CGPoint(x: x, y: y))
                }
                else {
                    // initial point
                    path.move(to: CGPoint(x: x, y: y))
                }
            }
        }
        
        return path
    }
}

struct AnimationListener: GeometryEffect {
    
    var onChange: (CGFloat) -> ()
    var animatableData: CGFloat {
        didSet {
            onChange(animatableData)
        }
    }
    
    func effectValue(size: CGSize) -> ProjectionTransform {
        return .init()
    }
}

class AnimationGraphDataModel: ObservableObject {
    
    /// All points of the graph
    @Published var points: [GraphPoint] = []
    
    /// Adds a point to the graph
    func addPoint(percentage: CGFloat) {
        DispatchQueue.main.async {
            self.points.append(GraphPoint(time: CGFloat(CACurrentMediaTime()), percentage: percentage))
        }
    }
    
    /// Removes all points from the graph.
    func clearPoints() {
        DispatchQueue.main.async {
            self.points = []
        }
    }
}
