//
//  ConfigurationView.swift
//  Bounce
//
//  Created by Leon Böttger on 06.04.23.
//

import SwiftUI

struct ConfigurationView: View {
    
    let animation: AnimationWrapper
    
    var body: some View {
        
        ZStack {
            switch animation.configuration {
                
            case let configuration as DurationConfiguration:
                DurationConfigurationView(configuration: configuration)
            case let configuration as SpringConfiguration:
                SpringConfigurationView(configuration: configuration)
            case let configuration as InterpolatingSpringConfiguration:
                InterpolatingSpringConfigurationView(configuration: configuration)
            default:
                Text("Error")
                
            }
        }
    }
}

struct DurationConfigurationView: View {
    
    @ObservedObject var configuration: DurationConfiguration
    
    var body: some View {
        CustomSlider(label: "Duration", unit: "s", value: $configuration.duration, upper: 3, lower: 0)
    }
}

struct SpringConfigurationView: View {
    
    @ObservedObject var configuration: SpringConfiguration
    
    var body: some View {
        VStack {
            
            CustomSlider(label: "Damping Fraction", unit: "", value: $configuration.dampingFraction, upper: 1.5, lower: 0)
            
            CustomSlider(label: "Response", unit: "", value: $configuration.response, upper: 3, lower: 0)
        }
    }
}

struct InterpolatingSpringConfigurationView: View {
    
    @ObservedObject var configuration: InterpolatingSpringConfiguration
    
    var body: some View {
        VStack {
            
            CustomSlider(label: "Mass", unit: "", value: $configuration.mass, upper: 1.5, lower: 0)
            
            CustomSlider(label: "Stiffness", unit: "", value: $configuration.stiffness, upper: 200, lower: 0)
            
            CustomSlider(label: "Damping", unit: "", value: $configuration.damping, upper: 10, lower: 0)
            
            CustomSlider(label: "Initial Velocity", unit: "", value: $configuration.initialVelocity, upper: 20, lower: 0)
        }
    }
}

struct CustomSlider: View {
    
    let label: String
    let unit: String
    
    @Binding var value: Double
    let upper: Double
    let lower: Double
    
    var body: some View {
        HStack {
            Text("\(label):")
                .opacity(0.5)
            
            Slider(value: $value, in: lower...upper) {}
            
            Text(String(format: "%.2f\(unit)", value))
                .frame(width: 60)
                .opacity(0.5)
        }
    }
}
