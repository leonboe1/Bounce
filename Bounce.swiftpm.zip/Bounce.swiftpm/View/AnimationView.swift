//
//  AnimationView.swift
//  Bounce
//
//  Created by Leon Böttger on 05.04.23.
//

import SwiftUI

struct AnimationView: View {
    
    @StateObject var graph = AnimationGraphDataModel()
    @State var offsetPct: CGFloat = 0
    
    let animation: AnimationWrapper
    
    var body: some View {
        
        GeometryReader { geo in
            
            let padding = max(30, max(0, (geo.size.width-Constants.maxWidth)/2))
            let iconSize: CGFloat = isiPad() ? 100 : 70
            let moveWidth = geo.size.width - iconSize - padding*2
            
            if(moveWidth > 0) {
                BigButtonView(buttonHeight: Constants.labelHeight, mainView: AnimationMainView(graph: graph, iconSize: iconSize, animation: animation, moveWidth: moveWidth, padding: padding, offsetPct: $offsetPct), buttonView: AnimationStartButtonView(graph: graph, animation: animation, offsetPct: $offsetPct))
            }
        }
        .navigationTitle(animation.name)
    }
}

struct AnimationMainView: View {
    
    let graph: AnimationGraphDataModel
    let iconSize: CGFloat
    let animation: AnimationWrapper
    let moveWidth: CGFloat
    let padding: CGFloat
    @Binding var offsetPct: CGFloat
    
    var body: some View {
        VStack(spacing: 20) {
            
            Spacer()
            
            TrainView(graph: graph, moveWidth: moveWidth, iconSize: iconSize, offsetPct: offsetPct)
            
            Spacer()
            
            Group {
                Text(animation.codeFormat)
                    .font(.system(.body, design: .monospaced))
                    .fixedSize(horizontal: false, vertical: true)
                    .opacity(0.9)
                    .padding()
                
                Text(animation.description)
                    .lineSpacing(8)
                    .fixedSize(horizontal: false, vertical: true)
                    .opacity(0.8)
            }
            
            Spacer()
            
            GraphView(graph: graph, moveWidth: moveWidth)
            
            Spacer()
            
            ConfigurationView(animation: animation)
            
            Spacer()
            Spacer()
        }
        .padding(.horizontal, padding)
    }
}

struct AnimationStartButtonView: View {
    
    let graph: AnimationGraphDataModel
    let animation: AnimationWrapper
    @Binding var offsetPct: CGFloat
    
    var body: some View {
        LargeButton(imageName: "play.fill", description: "Animate!") {
            trigger()
        }
        .padding(.top)
        .onAppear{
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                trigger()
            }
        }
    }
    
    func trigger() {
        graph.clearPoints()
        
        withAnimation(animation.getAnimation()) {
            if(offsetPct == 0) {
                offsetPct = 1
            }
            else {
                offsetPct = 0
            }
        }
    }
}

struct TrainView: View {
    
    let graph: AnimationGraphDataModel
    let moveWidth: CGFloat
    let iconSize: CGFloat
    let offsetPct: CGFloat
    
    var body: some View {
        
        VStack(spacing: 0) {
            Text("🚃")
                .font(.system(size: iconSize))
                .offset(x: offsetPct * moveWidth)
                .modifier(AnimationListener(onChange: { newVal in
                    graph.addPoint(percentage: newVal)
                }, animatableData: offsetPct))
                .frame(maxWidth: .infinity, alignment: .leading)
            
            
            Rectangle()
                .frame(height: 1)
                .offset(y: -10)
                .foregroundColor(.gray)
                .opacity(0.6)
        }
    }
}

/// returns is device is an iPad
func isiPad() -> Bool {
    let device = UIDevice.current
    
    let iPad = device.model == "iPad"
    
    return iPad
}
