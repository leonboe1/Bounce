//
//  NavigationLinkView.swift
//  Bounce
//
//  Created by Leon Böttger on 06.04.23.
//

import SwiftUI

/// navigation link to animation
struct AnimationOverviewView: View {
    
    let animation: AnimationWrapper
    
    var body: some View {
        
        HStack {
            Text(animation.name)
                .foregroundColor(.primary.opacity(0.8))
            Spacer()
            Image(systemName: "chevron.right")
                .foregroundColor(.primary.opacity(0.5))
        }
        .modifier(FieldModifier(color: .clear))
    }
}

/// adds color, shadow and corners to item
struct CustomFormModifier: ViewModifier {
    @Environment(\.colorScheme) var colorScheme
    
    func body(content: Content) -> some View {
        content
            .padding(.horizontal)
            .background(Color("FormForeground"))
            .cornerRadius(15)
            .compositingGroup()
            .modifier(ShadowModifier())
    }
}

/// adds shadow to item
struct ShadowModifier: ViewModifier {
    @Environment(\.colorScheme) var colorScheme
    
    func body(content: Content) -> some View {
        content
            .shadow(color: Color.gray.opacity(colorScheme == .light ? 0.2 : 0), radius: 7, x: 1, y: 1)
    }
}


/// adds rounded rectangle to content
struct FieldModifier: ViewModifier {
    
    var color: Color
    
    func body(content: Content) -> some View {
        content
            .frame(minHeight: Constants.labelHeight)
            .padding(.horizontal)
            .background(color.cornerRadius(Constants.cornerRadius))
    }
}
